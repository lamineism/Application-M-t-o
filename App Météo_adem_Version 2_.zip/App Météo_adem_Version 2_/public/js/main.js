/*main.js ; ç le fichier principal , point d'entrée de notre application
il gère tous les événements et interactions utilisateur
   chaque opération (recherche, coordonnées, bbox, région)
   affiche ses résultats dans son propre conteneur
   les résultats ne se mélangent pas entre les sections */

//Les Imports

import { fetchWeather, searchCitiesInRegion, searchCityByName } from "./api.js";
/* fetchWeather : récupère la météo pour des coordonnées lat/lon
   searchCityByName : recherche les coordonnées d'une ville par son nom
   searchCitiesInRegion : recherche des villes dans une région (on a fait le bonus)*/

import { clearLoading, displaySavedLocations, displayWeather, showLoading } from "./userInterface.js";
/* showLoading : affiche le message de chargement dans un conteneur
   clearLoading : enlève le message de chargement d'un conteneur
   displayWeather : crée et affiche une carte météo dans un conteneur ciblé
   displaySavedLocations : affiche la liste des villes sauvegardées */

import { clearLocations, getSavedLocations, removeLocation, saveLocation } from "./storage.js";
/* saveLocation : enregistre une ville dans localStorage
   getSavedLocations : récupère toutes les villes enregistrées
   clearLocations : supprime toutes les villes
   removeLocation : supprime une ville par index */

import { applyFilters } from "./filters.js";
/* applyFilters : montre/cache les informations selon les checkboxes */

import { filterByBoundingBox, filterByRegion } from "./bbox.js";
/* filterByBoundingBox : filtre les villes par zone géographique
   filterByRegion : filtre les villes par nom de région/département */

import { validateBoundingBox } from "./fonctions_utilitaires.js";
/* validateBoundingBox : vérifie que les 4 champs de la bounding box sont valides */

/*fonction utilitaire : obtenir la grille d'une section
   chaque section a un div .results-container avec un .results-grid dedans
   et cette fonction retourne le .results-grid et rend le conteneur visible*/

/* getResultsGrid : cette fonction ;
   retourne l'élément .results-grid à l'intérieur d'un conteneur de résultats
   et rend le conteneur visible (display: block)
   containerId = l'id du div .results-container (ex:"search-results") */
function getResultsGrid(containerId) {
    const container = document.getElementById(containerId);
    /*ici on récupère le conteneur de résultats par son id */

    container.style.display = "block";
    /*ici on rend le conteneur visible
       car il était caché par défaut (style="display:none" dans le html) */

    return container.querySelector(".results-grid");
    /* on retourne la grille à l'intérieur du conteneur
       c'est dans cette grille qu'on ajoutera les cartes météo */
}

//fonctions utilitaires locales


/* refreshSavedList : cette fonction :
   rafraîchit l'affichage de la liste des villes sauvegardées */
function refreshSavedList() {
    const locations = getSavedLocations();
    displaySavedLocations(locations, handleClickSavedCity, handleDeleteSavedCity);
}

/* handleClickSavedCity : cette fonction :
   appelée quand l'utilisateur clique sur une ville sauvegardée
   et affiche la météo dans la section "saved-results"
   les cartes précédentes restent affichées(on ajoute à côté) */
async function handleClickSavedCity(loc) {
    /*ici on récupère la grille de résultats de la section "Villes sauvegardées" */
    const grid = getResultsGrid("saved-results");
    /*getResultsGrid rend aussi le conteneur visible automatiquement */

    showLoading(grid);
    /*là affiche le chargement dans cette grille spécifique */

    const data = await fetchWeather(loc.lat, loc.lon);

    clearLoading(grid);
    /*on enlève le chargement de cette grille */

    displayWeather(loc.name, data, grid);
    /*ici on affiche la carte dans la grille des villes sauvegardées
       le 3ème paramètre "grid" indique OÙ ajouter la carte
       et les autres sections ne sont pas touchées */

    applyFilters();
}

/* handleDeleteSavedCity : cette fonction :
   supprime une ville du localStorage et rafraîchit la liste */
function handleDeleteSavedCity(index) {
    removeLocation(index);
    refreshSavedList();
}

//initialisation au chargement de la page

document.addEventListener("DOMContentLoaded", async () => {
    /*DOMContentLoaded se déclenche quand le html est complètement chargé */

    //---Affichage des villes sauvegardées-----
    refreshSavedList();

    //---- Chargement automatique de Blois---------- 
    //Blois s'affiche dans sa propre section "default-results"
    const defaultGrid = document.getElementById("default-results");
    /* default-results n'a pas de .results-container car il est toujours visible */

    showLoading(defaultGrid);

    const bloisData = await fetchWeather(47.5861, 1.3359);
    // 47.5861, 1.3359 sont les coordonnées de Blois 

    clearLoading(defaultGrid);
    displayWeather("Blois", bloisData, defaultGrid);
    // ici on affiche Blois dans la section par défaut

    applyFilters();

    //------événements pour les boutons X de fermeture des résultats----------
    //chaque section a un bouton X (close-results-btn) qui cache le conteneur entier
    document.querySelectorAll(".close-results-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            const targetId = btn.getAttribute("data-target");
            /*data-target contient l'id du conteneur à cacher
               ex: data-target="search-results" */

            const container = document.getElementById(targetId);
            container.style.display = "none";
            /* On cache le conteneur */

            const grid = container.querySelector(".results-grid");
            grid.innerHTML = "";
            /* On vide aussi les cartes à l'intérieur
               comme ça quand on recliquera c'est propre */
        });
    });
});

/*événement : recherche par nom de ville
  Les résultats s'affichent dans #search-results*/

document.getElementById("search-city-btn").addEventListener("click", async () => {
    const city = document.getElementById("city-search").value.trim();

    if (!city) {
        alert("Veuillez entrer un nom de ville.");
        return;
    }

    /*ici on récupère la grille de la section recherche */
    const grid = getResultsGrid("search-results");
    /* le conteneur search-results devient visible */

    showLoading(grid);

    try {
        const results = await searchCityByName(city);

        if (results.length === 0) {
            clearLoading(grid);
            alert("Ville non trouvée.");
            return;
        }

        const lat = results[0].lat;
        const lon = results[0].lon;

        const data = await fetchWeather(lat, lon);

        clearLoading(grid);
        displayWeather(city, data, grid);
        /*la carte s'affiche dans la section recherche uniquement */

        saveLocation({ name: city, lat, lon });
        refreshSavedList();
        applyFilters();
    } catch (error) {
        clearLoading(grid);
        alert("Erreur lors de la recherche.");
        console.error("Erreur recherche ville :", error);
    }
});

/* Rechercher en appuyant sur Entrée */
document.getElementById("city-search").addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
        document.getElementById("search-city-btn").click();
    }
});

/*événement : ajout manuel par coordonnées
et les résultats s'affichent dans #coords-results*/

document.getElementById("add-location-btn").addEventListener("click", async () => {
    const lat = document.getElementById("latitude").value;
    const lon = document.getElementById("longitude").value;

    if (!lat || !lon) {
        alert("Veuillez entrer latitude et longitude.");
        return;
    }

    /*là on récupère la grille de la section coordonnées */
    const grid = getResultsGrid("coords-results");

    showLoading(grid);

    try {
        const data = await fetchWeather(lat, lon);

        clearLoading(grid);

        const locationName = `Lieu (${parseFloat(lat).toFixed(2)}, ${parseFloat(lon).toFixed(2)})`;
        displayWeather(locationName, data, grid);
        /* la carte s'affiche dans la section coordonnées uniquement */

        saveLocation({ name: locationName, lat, lon });
        refreshSavedList();
        applyFilters();

        document.getElementById("latitude").value = "";
        document.getElementById("longitude").value = "";
    } catch (error) {
        clearLoading(grid);
        alert("Erreur lors de la récupération météo.");
        console.error("Erreur ajout coordonnées :", error);
    }
});

//----événement: filtres (checkboxes)------------------------------------------

document.querySelectorAll("input[type=checkbox]").forEach(cb => {
    cb.addEventListener("change", applyFilters);
});

//--événement : supprimer toutes les villes----

document.getElementById("clear-saved-btn").addEventListener("click", () => {
    if (confirm("Voulez-vous vraiment supprimer toutes les villes sauvegardées ?")) {
        clearLocations();
        refreshSavedList();
    }
});

/*événement : bounding box (formulaire)
   les résultats s'affichent dans #bbox-results*/

document.getElementById("bbox-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const minLat = parseFloat(document.getElementById("min-lat").value);
    const maxLat = parseFloat(document.getElementById("max-lat").value);
    const minLon = parseFloat(document.getElementById("min-lon").value);
    const maxLon = parseFloat(document.getElementById("max-lon").value);

    const errorEl = document.getElementById("bbox-error");

    //La validation côté client----
    const validation = validateBoundingBox(minLat, maxLat, minLon, maxLon);

    if (!validation.valid) {
        errorEl.textContent = validation.message;
        errorEl.style.display = "block";
        return;
    }

    errorEl.style.display = "none";

    const filteredLocations = filterByBoundingBox(minLat, maxLat, minLon, maxLon);

    if (filteredLocations.length === 0) {
        alert("Aucune ville sauvegardée dans cette zone.");
        return;
    }

    //ici on récupère la grille de la section bounding box
    const grid = getResultsGrid("bbox-results");
    //ici on vide les résultats précédents de cette section
    grid.innerHTML = "";

    showLoading(grid);

    for (const loc of filteredLocations) {
        const data = await fetchWeather(loc.lat, loc.lon);
        displayWeather(loc.name, data, grid);
        //chaque ville filtrée s'affiche dans la section bbox
    }

    clearLoading(grid);
    applyFilters();
});

/*événement : filtrage par région/département
les résultats s'affichent dans #region-results*/

document.getElementById("filter-region-btn").addEventListener("click", async () => {
    const regionName = document.getElementById("region-search").value.trim();

    if (!regionName) {
        alert("Veuillez entrer un nom de département ou de région.");
        return;
    }

    //On récupère la grille de la section région
    const grid = getResultsGrid("region-results");
    //on vide les résultats précédents
    grid.innerHTML = "";

    showLoading(grid);

    try {
        const filteredLocations = await filterByRegion(regionName);

        if (filteredLocations.length === 0) {
            clearLoading(grid);
            alert("Aucune ville sauvegardée dans cette région/département.");
            return;
        }

        for (const loc of filteredLocations) {
            const data = await fetchWeather(loc.lat, loc.lon);
            displayWeather(loc.name, data, grid);
            //chaque ville filtrée s'affiche dans la section région
        }

        clearLoading(grid);
        applyFilters();
    } catch (error) {
        clearLoading(grid);
        alert("Erreur lors du filtrage par région.");
        console.error("Erreur filtrage région :", error);
    }
});

/* //événement : découvrir des villes (on a fait ce bonus)
les villes découvertes s'affichent dans #discover-results
le bouton "Météo" ouvre la carte dans la section région*/

document.getElementById("discover-btn").addEventListener("click", async () => {
    const regionName = document.getElementById("discover-region").value.trim();

    if (!regionName) {
        alert("Veuillez entrer un nom de région ou département.");
        return;
    }

    const resultsContainer = document.getElementById("discover-results");
    resultsContainer.innerHTML = '<p class="info-text">Recherche en cours...</p>';

    try {
        const cities = await searchCitiesInRegion(regionName);

        resultsContainer.innerHTML = "";

        if (cities.length === 0) {
            resultsContainer.innerHTML = '<p class="info-text">Aucune ville trouvée dans cette zone.</p>';
            return;
        }

        cities.forEach(city => {
            const item = document.createElement("div");
            item.classList.add("discover-item");

            const nameSpan = document.createElement("span");
            nameSpan.textContent = city.name;

            //Bouton "Météo" : affiche la carte dans la section région
            const meteoBtn = document.createElement("button");
            meteoBtn.textContent = "Météo";
            meteoBtn.classList.add("btn-small");
            meteoBtn.addEventListener("click", async () => {
                /*ici on utilise la grille de la section région pour la météo découverte */
                const grid = getResultsGrid("region-results");
                showLoading(grid);
                const data = await fetchWeather(city.lat, city.lon);
                clearLoading(grid);
                displayWeather(city.name, data, grid);
                applyFilters();
            });

            //Bouton "Sauvegarder"
            const saveBtn = document.createElement("button");
            saveBtn.textContent = "Sauvegarder";
            saveBtn.classList.add("btn-small", "btn-success");
            saveBtn.addEventListener("click", () => {
                const saved = saveLocation({ name: city.name, lat: city.lat, lon: city.lon });

                if (saved) {
                    refreshSavedList();
                    saveBtn.textContent = "Fait !";
                    saveBtn.disabled = true;
                } else {
                    saveBtn.textContent = "Déjà ajoutée";
                    saveBtn.disabled = true;
                }
            });

            item.appendChild(nameSpan);
            item.appendChild(meteoBtn);
            item.appendChild(saveBtn);
            resultsContainer.appendChild(item);
        });

    } catch (error) {
        resultsContainer.innerHTML = '<p class="info-text">Erreur lors de la recherche.</p>';
        console.error("Erreur découverte villes :", error);
    }
});
