/* bbox.js : filtrage géographique
filtre les villes sauvegardées par bounding box ou par département/région*/

import { isInBoundingBox } from "./fonctions_utilitaires.js";
import { getSavedLocations } from "./storage.js";

/* filterByBoundingBox :
   filtre les villes enregistrées pour ne garder que celles
   comprises dans la zone définie par minLat, maxLat, minLon et maxLon */
export function filterByBoundingBox(minLat, maxLat, minLon, maxLon) {
    const locations = getSavedLocations();
    /*ici on récupère toutes les villes enregistrées dans localStorage
       et ensuite on filtre uniquement parmi les villes que l'utilisateur a ajoutées*/

    return locations.filter(loc =>
        isInBoundingBox(
            parseFloat(loc.lat),
            parseFloat(loc.lon),
            minLat,
            maxLat,
            minLon,
            maxLon
        )
    );
    /*filter() permet de créer un nouveau tableau avec seulement les éléments qui passent le test
      et parseFloat : convertit les coordonnées stockées en string vers des nombres*/
}

/* filterByRegion :
   filtre les villes sauvegardées en utilisant la bounding box d'une région ou département
   étape1 : on cherche la bounding box de la région via Nominatim
   étape2: on filtre les villes sauvegardées avec cette bounding box*/
export async function filterByRegion(regionName) {
    /*là on cherche la région sur Nominatim pour obtenir sa bounding box*/
    const url = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(regionName)}`
        + `&limit=1`
        + `&accept-language=fr`
        + `&countrycodes=fr`; //pour éviter les régions avec le même nom
    /*encodeURIComponent encode les caractères spéciaux pour l'URL
       limit=1 car on veut que le premier résultat (le plus pertinent)*/

    const response = await fetch(url);
    const results = await response.json();

    if (results.length === 0) {
        return [];
        /*si la région n'est pas trouvée alors on retourne un tableau vide*/
    }

    /*Nominatim retourne une bounding box sous la forme [latMin, latMax, lonMin, lonMax] */
    const bbox = results[0].boundingbox;
    const minLat = parseFloat(bbox[0]);
    const maxLat = parseFloat(bbox[1]);
    const minLon = parseFloat(bbox[2]);
    const maxLon = parseFloat(bbox[3]);
    /*là on convertit en nombres avec parseFloat car Nominatim retourne des strings */

    /*ici on réutilise filterByBoundingBox pour filtrer les villes */
    return filterByBoundingBox(minLat, maxLat, minLon, maxLon);
    /*comme ça on duplique pas la logique de filtrage, on réutilise la fonction déjà existante*/
}
