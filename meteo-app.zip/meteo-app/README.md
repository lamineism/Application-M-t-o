# Application Météo – Projet Web Client L3

## Description
Application météo en JavaScript client utilisant :
- Open-Meteo API
- Nominatim OpenStreetMap API

## Fonctionnalités

- Météo actuelle de Blois
- Détail journalier (min/max)
- Détail heure par heure
- Tendance des prochains jours
- Multi-localisations
- Sauvegarde en localStorage
- Recherche par nom
- Filtrage via Bounding Box

## Lancement

Ouvrir index.html dans un navigateur moderne.
