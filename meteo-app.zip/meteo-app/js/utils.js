export function isInBoundingBox(lat, lon, minLat, maxLat, minLon, maxLon) {
    return lat >= minLat &&
           lat <= maxLat &&
           lon >= minLon &&
           lon <= maxLon;
    /*cette fonction vérifie si une ville est comprise
     dans la bounding box fournie par l’utilisateur*/
}

export function computeTrend(data) {
    const aujourdhui = data.daily.temperature_2m_max[0];
    const demain = data.daily.temperature_2m_max[1];

    if (demain > aujourdhui) return "Amélioration";
    if (demain < aujourdhui) return "Détérioration";
    return "Stable"; // car ici rien ne change 
    /*là permet de 
     comparer la température max de demain avec celle d’aujourd’hui
     Retourne une tendance simple (Amélioration/Détérioration/Stable)*/
}
