import { computeTrend } from "./utils.js";
/* on importe computeTrend 
pour calculer la tendance météo (Amélioration/Détérioration/Stable) */

/*FONCTIONS DE CHARGEMENT*/
export function showLoading() {
    const container = document.getElementById("weather-container"); 
    /*on utilise getElementById
    pour accéder au conteneur où on affiche les cartes météo */

    container.innerHTML = "<p>Chargement en cours...</p>"; 
    /*on utilise innerHTML ici 
    pour afficher un petit message simple pendant que l'API répond */
}

export function clearLoading() {
    const container = document.getElementById("weather-container");
    container.innerHTML = ""; 
    /* cette fonction clearLoading 
    permet de supprimer le message de chargement 
    ou les anciennes cartes avant un nouvel affichage */
}


  // Affiche d'une carte météo 

export function displayWeather(locationName, data) {

    const container = document.getElementById("weather-container");

    // Sécurité si problème API
    if (!data || !data.current_weather || !data.daily) {
        // container.innerHTML += ` : ajoute dynamiquement du HTML à la fin du contenu existant
        container.innerHTML += `  
            <div class="weather-card">
                <h3>${locationName}</h3>
                <p>Impossible de récupérer les données météo.</p>
            </div>
        `;
        /* ce test évite que la page plante si l’API ne renvoie rien ou est incorrecte */
        return;
    }

    const card = document.createElement("div");
    card.classList.add("weather-card"); 
    /* là on crée une div et on ajoute une classe 
       car chaque ville a sa propre carte avec bordure et style */

    card.innerHTML = `
        <h3>${locationName}</h3>
        <div class="temp">Température : ${data.current_weather.temperature}°C</div>
        <div class="wind">Vent : ${data.current_weather.windspeed} km/h</div>
        <div>Min : ${data.daily.temperature_2m_min[0]}°C</div>
        <div>Max : ${data.daily.temperature_2m_max[0]}°C</div>
        <button class="hourly-btn">Voir heure par heure</button>
        <div class="hourly-container" style="display:none;"></div>
    `;
    // ces champs:
    /* affiche toutes les informations demandées sur notre projet :
        - Température actuelle
        - Vent
        - Min / Max du jour
        - Bouton pour heure par heure
        - Conteneur caché pour données horaires */

    const hourlyBtn = card.querySelector(".hourly-btn");
    const hourlyDiv = card.querySelector(".hourly-container");

    /*querySelector:
      pour manipuler les éléments spécifiques à cette carte */

    hourlyBtn.addEventListener("click", () => {

        if (hourlyDiv.style.display === "none") {

            hourlyDiv.style.display = "block";
            hourlyDiv.innerHTML = "";

            for (let i = 0; i < 12 && i < data.hourly.time.length; i++) {
                hourlyDiv.innerHTML += `
                    <p>${data.hourly.time[i]} :
                    ${data.hourly.temperature_2m[i]}°C</p>
                `;
            }
            hourlyBtn.textContent = "Masquer"; 
            /* on change le texte du bouton 
            / pour indiquer à l’utilisateur qu’on peut maintenant masquer les détails */

        } else {
            hourlyDiv.style.display = "none";
            hourlyBtn.textContent = "Voir heure par heure";
        }
    });

    container.appendChild(card); 
    /* on utilise appendChild :
    pour ajouter la carte météo au conteneur principal */

    // Mise à jour de la tendance globale
    const trendSection = document.getElementById("trend-section");
    trendSection.innerHTML = `
        <h2>Tendance : ${computeTrend(data)}</h2>
    `;
    /*ici on utilise computeTrend ici 
    pour afficher la tendance météo globale (Amélioration/Détérioration/Stable) */
}
