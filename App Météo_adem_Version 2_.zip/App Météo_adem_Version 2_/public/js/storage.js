/*Stockage local (localStorage):
Gestion de la sauvegarde des villes*/

const STORAGE_KEY = "saved_locations";
/* On utilise une constante pour centraliser le nom de la clé localStorage
   et si on change le nom on n'a qu'un seul endroit à modifier*/

/* saveLocation: cette fonction
   ajoute une nouvelle ville à la liste des villes sauvegardées
   et elle vérifie si la ville n'est pas déjà enregistrée*/
export function saveLocation(location) {
    const locations = getSavedLocations(); //on récupère les villes déjà enregistrées

    /*on doit vérifier si la ville existe déjà pour éviter les doublons
      en comparant les coordonnées(lat/lon) arrondies à 2 décimales*/
    const existe = locations.some(loc =>
        parseFloat(loc.lat).toFixed(2) === parseFloat(location.lat).toFixed(2) &&
        parseFloat(loc.lon).toFixed(2) === parseFloat(location.lon).toFixed(2)
    );
    /*some() permet deretourner true si au moins un élément du tableau satisfait la condition
      toFixed(2): arrondit à 2 décimales pour éviter les problèmes de précision*/

    if (existe) {
        return false;
        //ici on retourne false pour indiquer que la ville existe déjà
    }

    locations.push(location);
    //ici on ajoute la nouvelle ville au tableau

    localStorage.setItem(STORAGE_KEY, JSON.stringify(locations));
    /*localStorage ne stocke que des chaînes de caractères 
    et JSON.stringify permets de convertir le tableau en string pour le stockage*/

    return true;
    //là on retourne true pour indiquer que la sauvegarde a réussi
}

/* getSavedLocations : cette fonction :
   récupère toutes les villes sauvegardées dans localStorage
   et retourne un tableau vide si aucune ville n'est enregistrée*/
export function getSavedLocations() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    /* JSON.parse reconvertit la string en tableau JavaScript
       ou [] : retourne un tableau vide si rien n'est stocké*/
}

/* clearLocations : cette fonction :
   supprime toutes les villes sauvegardées*/
export function clearLocations() {
    localStorage.removeItem(STORAGE_KEY);
    //removeItem supprime complètement la clé du localStorage
}

/* removeLocation : cette fonction
   supprime une ville spécifique par son index dans le tableau
   utilisé quand l'utilisateur clique sur le X d'une ville sauvegardée*/
export function removeLocation(index) {
    const locations = getSavedLocations();//ici on récupère le tableau actuel

    locations.splice(index, 1); /*splice(index, 1) supprime 1 élément à la position index
       ça modifie le tableau en place*/

    localStorage.setItem(STORAGE_KEY, JSON.stringify(locations));
    //pour resauvegarder le tableau mis à jour
}
