const STORAGE_KEY = "saved_locations"; 
/* on utilise une constante 
   pour centraliser le nom de la clé utilisée dans localStorage */

export function saveLocation(location) {
    const locations = getSavedLocations(); 
    /*on récupére les locations existantes 
    pour ajouter la nouvelle ville sans écraser celles déjà enregistrées */

    locations.push(location); 
    //on utilise push pour ajouter la nouvelle localisation au tableau

    localStorage.setItem(STORAGE_KEY, JSON.stringify(locations)); 
    /*on utilise JSON.stringify car
    localStorage ne stocke que des chaînes donc on convertit le tableau en string 
    ( faut convertir en string ) */
}

export function getSavedLocations() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; 
    /* on utilise JSON.parse et || [] 
    car on récupère le tableau depuis localStorage
    et si aucune donnée alors on retourne un tableau vide */
}

export function clearLocations() {
    localStorage.removeItem(STORAGE_KEY); 
    //cette fonction permet de supprimer toutes les villes enregistrées
}
