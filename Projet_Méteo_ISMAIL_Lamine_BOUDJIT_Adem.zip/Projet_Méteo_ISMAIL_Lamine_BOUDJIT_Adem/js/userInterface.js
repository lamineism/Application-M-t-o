/*userInterface.js: affichage et interface
   toutes les fonctions qui créent et affichent du HTML
   chaque section a son propre conteneur de résultats
   les filtres sont maintenant intégrés dans chaque carte météo*/

import { computeTrend, computeMultiDayTrend, formatDate, formatHour, getWeatherDescription, getWeatherIcon } from "./fonctions_utilitaires.js";
/*ici on importe les fonctions utilitaires :
   .computeTrend : tendance entre aujourd'hui et demain
   .computeMultiDayTrend : tendance sur plusieurs jours
   .formatDate : formater une date en français
   .formatHour : formater une heure (ex:14h29)
   .getWeatherDescription : description du code météo
   .getWeatherIcon : icône svg du code météo (soleil, nuage, pluie, etc...)*/

//les fonctions de chargement

/*showLoading :
   affiche un message de chargement dans un conteneur donné
   targetGrid = l'élément .results-grid dans lequel afficher le loading*/
export function showLoading(targetGrid) {
    /*on vérifie qu'il n'y a pas déjà un message de chargement dans ce conteneur*/
    if (!targetGrid.querySelector(".loading-message")) {
        const loadingDiv = document.createElement("div");
        loadingDiv.classList.add("loading-message");
        loadingDiv.textContent = "Chargement en cours";
        targetGrid.appendChild(loadingDiv);
        /*appendChild ajoute le loading sans effacer les cartes existantes*/
    }
}

/* clearLoading:
   supprime le message de chargement d'un conteneur donné */
export function clearLoading(targetGrid) {
    const loading = targetGrid.querySelector(".loading-message");
    if (loading) {
        loading.remove();
        /*remove() : elle supprime seulement le message et pas les cartes */
    }
}

//affichage de la tendance globale

/*updateTrend: cette fonction
   elle met à jour la section tendance avec les données de la dernière ville affichée*/
export function updateTrend(data) {
    const trendSection = document.getElementById("trend-section");

    if (!data || !data.daily) {
        trendSection.innerHTML = "";
        return;
    }

    /*on calcule les deux types de tendance*/
    const trendDemain = computeTrend(data);
    const trendGlobal = computeMultiDayTrend(data);

    trendSection.innerHTML = `
        <div class="section-header">
            <div class="section-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="m22 2-7 20-4-9-9-4 20-7Z"/>
                    <path d="M22 2 11 13"/>
                </svg>
            </div>
            <div>
                <h2 class="section-title">Tendance météo</h2>
                <p class="section-desc">Évolution prévue des conditions</p>
            </div>
        </div>
        <div style="display: flex; gap: var(--space-lg); flex-wrap: wrap;">
            <div style="flex: 1; min-width: 200px; padding: var(--space-lg); background: var(--color-background); border-radius: var(--radius-lg);">
                <p style="font-size: var(--font-size-sm); color: var(--color-text-muted); margin-bottom: var(--space-xs);">Demain</p>
                <p class="${trendDemain.cssClass}" style="font-size: var(--font-size-lg); font-weight: 600;">${trendDemain.text}</p>
            </div>
            <div style="flex: 1; min-width: 200px; padding: var(--space-lg); background: var(--color-background); border-radius: var(--radius-lg);">
                <p style="font-size: var(--font-size-sm); color: var(--color-text-muted); margin-bottom: var(--space-xs);">Prochains jours</p>
                <p class="${trendGlobal.cssClass}" style="font-size: var(--font-size-lg); font-weight: 600;">${trendGlobal.text}</p>
            </div>
        </div>
    `;
}

//gestion des filtres dans la carte

/* applyCardFilters :
   applique les filtres d'affichage à une carte spécifique
   card = l'élément DOM de la carte météo
   filters = objet { temp, wind, precip, minmax } avec des booléens */
function applyCardFilters(card, filters) {
    /*pour chaque type de donnée on parcourt tous les éléments ayant cette classe
       dans la carte et on change leur display selon l'état du filtre*/

    card.querySelectorAll(".temp").forEach(el => {
        el.style.display = filters.temp ? "" : "none";
    });

    card.querySelectorAll(".wind").forEach(el => {
        el.style.display = filters.wind ? "" : "none";
    });

    card.querySelectorAll(".precip").forEach(el => {
        el.style.display = filters.precip ? "" : "none";
    });

    card.querySelectorAll(".minmax").forEach(el => {
        el.style.display = filters.minmax ? "" : "none";
    });
}

/*affichage d'une carte météo
   fonction principale qui crée une carte complète
   les filtres sont maintenant intégrés dans la carte
   
   targetGrid : l'élément .results-grid où ajouter la carte
                chaque section a sa propre grille de résultats*/

export function displayWeather(locationName, data, targetGrid) {
    //sécurité si problème api
    if (!data || !data.current_weather || !data.daily) {
        const errorCard = document.createElement("div");
        errorCard.classList.add("weather-card");
        errorCard.innerHTML = `
            <div class="card-header">
                <h3>${locationName}</h3>
                <button class="close-card-btn" title="Fermer cette carte">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                        <path d="M18 6 6 18M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <p style="color: var(--color-text-secondary); text-align: center; padding: var(--space-xl);">Impossible de récupérer les données météo.</p>
        `;
        //bouton X pour fermer la carte d'erreur
        errorCard.querySelector(".close-card-btn").addEventListener("click", () => {
            errorCard.remove();
        });
        targetGrid.appendChild(errorCard);
        return;
    }

    //la création de la carte
    const card = document.createElement("div");
    card.classList.add("weather-card");

    //génération d'un id unique pour les checkboxes de cette carte
    const cardId = `card-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    //section 1: météo actuelle
    const currentWeatherCode = data.current_weather.weathercode || 0;
    const currentIcon = getWeatherIcon(currentWeatherCode);
    const currentDesc = getWeatherDescription(currentWeatherCode);

    /*le bouton X permet de supprimer cette carte sans toucher aux autres*/
    let currentHTML = `
        <div class="card-header">
            <h3>${locationName}</h3>
            <button class="close-card-btn" title="Fermer cette carte">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <path d="M18 6 6 18M6 6l12 12"/>
                </svg>
            </button>
        </div>
        <div class="current-weather-header">
            <div class="weather-icon">${currentIcon}</div>
            <div class="current-weather-details">
                <span class="current-desc">${currentDesc}</span>
                <span class="current-temp temp">${data.current_weather.temperature} °C</span>
            </div>
        </div>
        <div class="current-info">
            <span class="info-badge temp">Temp: ${data.current_weather.temperature} °C</span>
            <span class="info-badge wind">Vent: ${data.current_weather.windspeed} km/h</span>
            <span class="info-badge minmax">Min: ${data.daily.temperature_2m_min[0]} °C</span>
            <span class="info-badge minmax">Max: ${data.daily.temperature_2m_max[0]} °C</span>
    `;

    //précipitations si disponibles
    if (data.hourly && data.hourly.precipitation) {
        const precipTotal = data.hourly.precipitation.slice(0, 24).reduce((sum, val) => sum + val, 0);
        currentHTML += `<span class="info-badge precip">Precip: ${precipTotal.toFixed(1)} mm</span>`;
    }

    currentHTML += `</div>`;

    //section filtres intégrés dans la carte
    const filtersHTML = `
        <div class="card-filters">
            <span class="filters-label">Filtres :</span>
            <div class="filters-grid-inline">
                <label class="filter-label-inline">
                    <input type="checkbox" class="filter-cb" data-filter="temp" checked> Temp
                </label>
                <label class="filter-label-inline">
                    <input type="checkbox" class="filter-cb" data-filter="wind" checked> Vent
                </label>
                <label class="filter-label-inline">
                    <input type="checkbox" class="filter-cb" data-filter="precip" checked> Précip
                </label>
                <label class="filter-label-inline">
                    <input type="checkbox" class="filter-cb" data-filter="minmax" checked> Min/Max
                </label>
            </div>
        </div>
    `;

    //section 2 : prévisions des prochains jours
    let forecastHTML = `
        <h4>Prévisions des prochains jours</h4>
        <table class="forecast-days">
            <thead>
                <tr>
                    <th>Jour</th>
                    <th></th>
                    <th class="temp">Max</th>
                    <th class="temp">Min</th>
                    <th class="precip">Précip.</th>
                    <th>Météo</th>
                    <th>Détail</th>
                </tr>
            </thead>
            <tbody>
    `;

    for (let i = 0; i < data.daily.time.length; i++) {
        const dateFormatee = formatDate(data.daily.time[i]);
        const maxTemp = data.daily.temperature_2m_max[i];
        const minTemp = data.daily.temperature_2m_min[i];
        const precip = data.daily.precipitation_sum ? data.daily.precipitation_sum[i] : "-";
        const weatherCode = data.daily.weathercode ? data.daily.weathercode[i] : 0;
        const weatherDesc = getWeatherDescription(weatherCode);
        const dayIcon = getWeatherIcon(weatherCode);

        forecastHTML += `
            <tr>
                <td>${dateFormatee}</td>
                <td class="forecast-icon-cell">${dayIcon}</td>
                <td class="temp">${maxTemp} °C</td>
                <td class="temp">${minTemp} °C</td>
                <td class="precip">${precip} mm</td>
                <td>${weatherDesc}</td>
                <td><button class="day-detail-btn btn btn-small" data-day="${i}">Voir</button></td>
            </tr>
        `;
    }

    forecastHTML += `</tbody></table>`;

    //section 3 : conteneur horaire (caché)
    const hourlyHTML = `<div class="hourly-container" style="display:none;"></div>`;

    //assemblage de toutes les sections
    card.innerHTML = currentHTML + filtersHTML + forecastHTML + hourlyHTML;

    //événements : filtres de la carte
    const filterCheckboxes = card.querySelectorAll(".filter-cb");
    filterCheckboxes.forEach(cb => {
        cb.addEventListener("change", () => {
            const filters = {
                temp: card.querySelector('[data-filter="temp"]').checked,
                wind: card.querySelector('[data-filter="wind"]').checked,
                precip: card.querySelector('[data-filter="precip"]').checked,
                minmax: card.querySelector('[data-filter="minmax"]').checked
            };
            applyCardFilters(card, filters);
        });
    });

    //événements : boutons "Heures" pour chaque jour
    const dayButtons = card.querySelectorAll(".day-detail-btn");
    const hourlyDiv = card.querySelector(".hourly-container");

    dayButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const dayIndex = parseInt(btn.getAttribute("data-day"));
            const startHour = dayIndex * 24;
            const endHour = startHour + 24;

            /*si on reclique le même jour alors on ferme le détail*/
            if (hourlyDiv.style.display === "block" && hourlyDiv.getAttribute("data-active-day") === String(dayIndex)) {
                hourlyDiv.style.display = "none";
                hourlyDiv.removeAttribute("data-active-day");
                return;
            }

            //ici la construction du détail heure par heure
            hourlyDiv.innerHTML = `<strong>Détail heure par heure - ${formatDate(data.daily.time[dayIndex])}</strong>`;

            for (let i = startHour; i < endHour && i < data.hourly.time.length; i++) {
                const heure = formatHour(data.hourly.time[i]);
                const temp = data.hourly.temperature_2m[i];
                const precip = data.hourly.precipitation ? data.hourly.precipitation[i] : 0;
                const vent = data.hourly.windspeed_10m ? data.hourly.windspeed_10m[i] : "-";

                hourlyDiv.innerHTML += `
                    <p>
                        <strong>${heure}</strong> -
                        <span class="temp">${temp} °C</span> |
                        <span class="precip">Precip: ${precip}mm</span> |
                        <span class="wind">Vent: ${vent}km/h</span>
                    </p>
                `;
            }

            hourlyDiv.style.display = "block";
            hourlyDiv.setAttribute("data-active-day", dayIndex);

            /*appliquer les filtres actuels au contenu horaire*/
            const filters = {
                temp: card.querySelector('[data-filter="temp"]').checked,
                wind: card.querySelector('[data-filter="wind"]').checked,
                precip: card.querySelector('[data-filter="precip"]').checked,
                minmax: card.querySelector('[data-filter="minmax"]').checked
            };
            applyCardFilters(card, filters);
        });
    });

    //événement : bouton X pour fermer cette carte
    const closeBtn = card.querySelector(".close-card-btn");
    closeBtn.addEventListener("click", () => {
        card.remove();
        /*remove() supprime uniquement cette carte, les autres restent */
    });

    //ajout de la carte dans la grille ciblée
    targetGrid.appendChild(card);
    /*appendChild ajoute la carte à côté des cartes existantes
    et chaque section a sa propre grille donc les résultats sont séparés*/

    //mise à jour de la tendance globale
    updateTrend(data);
}

//affichage des villes sauvegardées

export function displaySavedLocations(locations, onClickCity, onDeleteCity) {
    const container = document.getElementById("saved-locations-list");
    container.innerHTML = "";

    if (locations.length === 0) {
        container.innerHTML = '<p class="info-text">Aucune ville sauvegardée pour le moment. Recherchez une ville et sauvegardez-la !</p>';
        return;
    }

    locations.forEach((loc, index) => {
        const item = document.createElement("div");
        item.classList.add("saved-item");

        const nameSpan = document.createElement("span");
        nameSpan.textContent = loc.name;
        nameSpan.addEventListener("click", () => onClickCity(loc));

        const deleteBtn = document.createElement("button");
        deleteBtn.classList.add("delete-saved");
        deleteBtn.textContent = "x";
        deleteBtn.title = "Supprimer cette ville";
        deleteBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            onDeleteCity(index);
        });

        item.appendChild(nameSpan);
        item.appendChild(deleteBtn);
        container.appendChild(item);
    });
}
