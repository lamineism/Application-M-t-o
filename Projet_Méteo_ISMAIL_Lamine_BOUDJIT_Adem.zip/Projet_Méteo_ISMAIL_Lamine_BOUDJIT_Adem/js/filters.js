/*filtres d'affichage :
   note: les filtres sont maintenant intégrés directement dans chaque carte météo
   ce fichier est conservé pour compatibilité mais n'est plus utilisé
   la logique de filtrage se trouve désormais dans userInterface.js (applyCardFilters) */

/* applyFilters - DÉPRÉCIÉ
   cette fonction n'est plus utilisée car chaque carte météo
   a maintenant ses propres filtres intégrés.
   les filtres sont gérés localement dans chaque carte via applyCardFilters dans userInterface.js */
export function applyFilters() {
    //fonction vide - gardée pour éviter les erreurs d'import si appelée
    console.log("applyFilters() est déprécié - les filtres sont maintenant dans chaque carte");
}
