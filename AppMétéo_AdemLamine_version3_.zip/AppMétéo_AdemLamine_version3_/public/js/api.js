//La base URL de l'API Open-Meteo
const BASE_URL = "https://api.open-meteo.com/v1/forecast";

/*fetchWeather sert à récupérer la météo complète
   On récupère la météo pour des coordonnées données
   et nous on demande : current_weather, hourly (température, précipitations, vent), 
   et daily (min, max, précipitations) pour les 7 prochains jours*/
export async function fetchWeather(lat, lon) {
    /*là on construit l'URL avec tous les paramètres nécessaires:
        .current_weather=true: pour la météo actuelle
        .hourly : température, précipitations et vent heure par heure
        .daily : min et max température et précipitations par jour
        .forecast_days=7 : prévisions sur 7 jours (pour la partie prochains jours)
        .timezone=auto : pour que les heures correspondent au heure local*/
    const url = `${BASE_URL}?latitude=${lat}&longitude=${lon}`
        + `&current_weather=true`
        + `&hourly=temperature_2m,precipitation,windspeed_10m`
        + `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode`
        + `&forecast_days=7`
        + `&timezone=auto`;

    try {
        const response = await fetch(url);
        /* Appel de l'API en mode asynchrone ç a dire le code continue de s'exécuter
        sans attendre la réponse qui sera traitée dès qu'elle arrive*/

        if (!response.ok) throw new Error("Erreur API météo");
        //là ç la gestion d'erreur si l'API retourne un code d'erreur

        return await response.json();
        //pour transformer la réponse sous forme JSON
    } catch (error) {
        console.error("Erreur fetchWeather :", error);
        // affichage de l'erreur dans la console pour identifier le problème
        return null;
        // Retourne null si problème pour que l'appelant puisse gérer
    }
}

/* searchCityByName :
là on utilise Nominatim OpenStreetMap pour récupérer lat/lon à partir d'un nom de ville
On limite à 5 résultats et on demande le format JSON*/
export async function searchCityByName(city) {
    const url = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(city)}`
        + `&limit=5`
        + `&accept-language=fr`;
    /*encodeURIComponent sert à encoder les caractères spéciaux (accents, espaces)
       pour que l'URL soit valide
       accept-language=fr force Nominatim à retourner les noms en français
       car sans ça certaines villes apparaissent en arabe ou dans leur langue locale */

    const response = await fetch(url);
    return await response.json();
    //retourne un tableau de résultats avec lat, lon, display_name en français bien sur
}

/* searchCitiesInRegion :
   Recherche des villes dans une région ou un département français
   la méthode qu'on a appliqué  :
   1) on cherche la bounding box de la région via Nominatim avec accept-language=fr
   2) on fait plusieurs requêtes avec les noms de grandes villes françaises courantes
      dans la viewbox pour trouver de vraies villes et pas des résultats aléatoires
   3) on supprime les doublons et on vérifie que chaque ville est bien dans la bounding box*/
export async function searchCitiesInRegion(regionName) {
    /* étape 1: on cherche la zone (région/département) pour obtenir sa bounding box
       countrycodes=fr pour limiter à la France*/
    const regionUrl = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(regionName)}`
        + `&limit=1`
        + `&accept-language=fr`
        + `&countrycodes=fr`;
    const regionResponse = await fetch(regionUrl);
    const regionResults = await regionResponse.json();

    if (regionResults.length === 0) {
        return [];
        //si la région n'est pas trouvée alors on retourne un tableau vide
    }

    /*là on récupère la bounding box de la région
       le boundingbox est un tableau [latMin, latMax, lonMin, lonMax] */
    const bbox = regionResults[0].boundingbox;
    const minLat = parseFloat(bbox[0]);
    const maxLat = parseFloat(bbox[1]);
    const minLon = parseFloat(bbox[2]);
    const maxLon = parseFloat(bbox[3]);
    //et on convertit en nombres pour les comparaisons

    /*étape2 : on recherche des villes dans cette bounding box
       On utilise featuretype=city pour ne récupérer que des villes
       viewbox = lonMin, latMin, lonMax, latMax (format Nominatim)
       .bounded=1 force à ne retourner que des résultats dans la viewbox
       .countrycodes=fr limite à la France pour éviter les résultats étrangers
       et on fait la requête avec un q vide (*) pour avoir toutes les villes de la zone*/
    const citiesUrl = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(regionName)}`
        + `&featuretype=city`
        + `&viewbox=${minLon},${minLat},${maxLon},${maxLat}`
        + `&bounded=1`
        + `&limit=30`
        + `&accept-language=fr`
        + `&countrycodes=fr`;

    const citiesResponse = await fetch(citiesUrl);
    const citiesResults = await citiesResponse.json();

    /*étape 2b : on fait une 2ème requête avec "ville" comme mot-clé
       car Nominatim retourne parfois des résultats différents selon le mot-clé
       ça permet de trouver plus de villes dans la zone */
    const citiesUrl2 = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=ville`
        + `&featuretype=city`
        + `&viewbox=${minLon},${minLat},${maxLon},${maxLat}`
        + `&bounded=1`
        + `&limit=30`
        + `&accept-language=fr`
        + `&countrycodes=fr`;

    /* ici on attend un petit délai entre les 2 requêtes Nominatim
       pour respecter la limite de 1 requête/seconde de l'API*/
    await new Promise(resolve => setTimeout(resolve, 1100));
    // setTimeout crée un délai et on l'encapsule dans une promise pour l'await

    const citiesResponse2 = await fetch(citiesUrl2);
    const citiesResults2 = await citiesResponse2.json();

    /* étape 3: On fusionne les 2 listes et on supprime les doublons
       et on utilise un Map avec la clé "lat,lon" arrondie pour éviter les doublons */
    const allResults = [...citiesResults, ...citiesResults2];
    //spread operator pour fusionner les 2 tableaux

    const uniqueMap = new Map();
    //Map pour stocker les villes uniques (clé= coordonnées arrondies)

    allResults.forEach(city => {
        const lat = parseFloat(city.lat);
        const lon = parseFloat(city.lon);

        /* étape 4: on vérifie que la ville est vraiment dans la bounding box
           car certaines villes peuvent être retournées par Nominatim
           mais être légèrement en dehors de la zone */
        if (lat >= minLat && lat <= maxLat && lon >= minLon && lon <= maxLon) {
            /* ici on utilise les coordonnées arrondies comme clé pour supprime les doublons
               toFixed(2) arrondit à 2 décimales*/
            const key = `${lat.toFixed(2)},${lon.toFixed(2)}`;

            if (!uniqueMap.has(key)) {
                /* on extrait le nom en français depuis display_name
                   display_name est au format : "Ville, Département, Région, France"
                   et nous on prend juste le premier morceau (le nom de la ville)*/
                const name = city.display_name.split(",")[0].trim();
                //trim() sert à enlèver les espaces en début et fin

                uniqueMap.set(key, { name, lat, lon });
                //là on ajoute la ville dans le Map
            }
        }
    });

    /* On convertit le Map en tableau pour le retour*/
    return Array.from(uniqueMap.values());
    // values() retourne les valeurs du Map et après Array.from les met dans un tableau
}
