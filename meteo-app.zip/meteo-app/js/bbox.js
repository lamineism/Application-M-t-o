import { getSavedLocations } from "./storage.js";
import { isInBoundingBox } from "./utils.js";

export function filterByBoundingBox(minLat, maxLat, minLon, maxLon) {
    const locations = getSavedLocations(); 
    // Question : Pourquoi récupérer toutes les villes enregistrées ?
    // -> On filtre uniquement parmi les villes que l’utilisateur a ajoutées

    return locations.filter(loc =>
        isInBoundingBox(
            parseFloat(loc.lat),
            parseFloat(loc.lon),
            minLat,
            maxLat,
            minLon,
            maxLon
        )
    );
    /*on utilise parseFloat car 
    les coordonnées sont stockées en string alors on convertit en nombres pour comparer */
}
