// Base URL de l'API Open-Meteo
const BASE_URL = "https://api.open-meteo.com/v1/forecast";

/* fetchWeather (récupèrer la météo)
   On récupère la météo pour des coordonnées données
   On demande current_weather, hourly, daily */
export async function fetchWeather(lat, lon) {
    const url = `${BASE_URL}?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=temperature_2m,precipitation&daily=temperature_2m_max,temperature_2m_min&timezone=auto`;

    try {
        const response = await fetch(url); // fait appel API
        if (!response.ok) throw new Error("Erreur API météo"); //gestion erreur
        return await response.json(); // Transformation JSON
    } catch (error) {
        console.error(error); // là c'est l'affichage erreur console
        return null; // Retourne null si problème
    }
}

/*searchCityByName
Utilise Nominatim OpenStreetMap pour récupérer lat/lon par nom de ville*/
export async function searchCityByName(city) {
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${city}`;
    const response = await fetch(url);
    return await response.json(); // permet de retourner un tableau de résultats (format json)
}
