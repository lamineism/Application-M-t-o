export function applyFilters() {
    const showTemp = document.getElementById("filter-temp").checked;
    const showWind = document.getElementById("filter-wind").checked;
    
    /* on utilise checked 
     pour récupèrer si l’utilisateur veut afficher ou non température et vent */

    document.querySelectorAll(".temp").forEach(el => {
        el.style.display = showTemp ? "block" : "none"; 
        /* on utilise style.display 
        car soit on montre ou cache les éléments selon le filtre */
    });

    document.querySelectorAll(".wind").forEach(el => {
        el.style.display = showWind ? "block" : "none";
    });
}
