// import des fonctions

import { fetchWeather, searchCityByName } from "./api.js";
/*ici on importe fetchWeather et searchCityByName:
pour récupérer la météo et convertir un nom de ville en coordonnées */

import { clearLoading, displayWeather, showLoading } from "./ui.js";
/*ici on importe displayWeather, showLoading, clearLoading
  pour afficher la météo et gérer l'indicateur de chargement */

import { saveLocation } from "./storage.js";
//saveLocation pour enregistrer les villes dans le localStorage

import { applyFilters } from "./filters.js";
/*applyFilters:
pour permettre à l’utilisateur de filtrer l’affichage température et vent */

import { filterByBoundingBox } from "./bbox.js";
/* filterByBoundingBox
pour filtrer les villes enregistrées selon une zone géographique */

// initialisation au chargement
document.addEventListener("DOMContentLoaded", async () => {

    /* on utilise DOMContentLoaded 
    pour s'assurer que le HTML est chargé avant d'exécuter JS */

    //Chargement automatique de Blois
    showLoading(); 
    /* on utilise showLoading pour
    afficher un message "Chargement..." et pour indiquer que l'API est en cours d'appel */

    const bloisData = await fetchWeather(47.5861, 1.3359); 
    //ces coordonnées sont celles de Blois, pour montrer la météo par défaut au chargement

    clearLoading(); 
    /* on utilise clearLoading pour
    enlèver le message de chargement... après réception des données */

    displayWeather("Blois", bloisData); 
    /* ici on utilise displayWeather à fin
    d'afficher la carte météo de Blois avec toutes les infos (temp, vent, min/max, tendance) */
});

//recherche par nom de ville
document.getElementById("search-city-btn")
    .addEventListener("click", async () => {

    const city = document.getElementById("city-search").value.trim(); 
    /* on utilise trim() pour
    supprimer les espaces inutiles au début et à la fin */

    if (!city) {
        alert("Veuillez entrer un nom de ville.");
        return; 
        //ce test sert à empêcher l'appel API si aucun nom n'est saisi
    }

    showLoading();

    try {
        const results = await searchCityByName(city); 
        //await : recherche les coordonnées de la ville de façon asynchrone

        if (results.length === 0) {
            clearLoading();
            alert("Ville non trouvée.");
            return; 
            //ce test pour gestion d’erreur si la ville n’existe pas dans Nominatim
        }

        const lat = results[0].lat;
        const lon = results[0].lon;
        //results[0] car : on prend le premier résultat comme coordonnée principale

        const data = await fetchWeather(lat, lon); 
        //ici on utilise fetchWeather pour récupèrer la météo pour la ville choisie

        clearLoading();

        displayWeather(city, data); 
        //on utilise displayWeather pour afficher la météo sur la page

        saveLocation({ name: city, lat, lon }); 
        //saveLocation: Sauvegarde la ville pour pouvoir l’utiliser plus tard
    } catch (error) {
        clearLoading();
        alert("Erreur lors de la recherche.");
        console.error(error); 
        //try/catch : Pour gérer les erreurs d’API et éviter que la page plante
    }
});

// ajour manuel des coordonées 
document.getElementById("add-location-btn")
    .addEventListener("click", async () => {

    const lat = document.getElementById("latitude").value;
    const lon = document.getElementById("longitude").value;

    if (!lat || !lon) {
        alert("Veuillez entrer latitude et longitude.");
        return; 
        //on peut pas faire l’appel API si y'en a des valeurs manquantes
    }

    showLoading();

    try {
        const data = await fetchWeather(lat, lon);

        clearLoading();

        displayWeather("Localisation personnalisée", data);
        saveLocation({ name: "Personnelle", lat, lon });
        //Personnelle : pour identifier une ville ajoutée manuellement
    } catch (error) {
        clearLoading();
        alert("Erreur lors de la récupération météo.");
        console.error(error);
    }
});

// filtres 
document.querySelectorAll("input[type=checkbox]")
    .forEach(cb => cb.addEventListener("change", applyFilters));
/*là on applique applyFilters chaque fois que l’utilisateur coche/décoche une case
 cela met à jour l’affichage des températures et du vent en temps réel */

// bounding box
document.getElementById("filter-bbox-btn")
    .addEventListener("click", async () => {

    const minLat = parseFloat(document.getElementById("min-lat").value);
    const maxLat = parseFloat(document.getElementById("max-lat").value);
    const minLon = parseFloat(document.getElementById("min-lon").value);
    const maxLon = parseFloat(document.getElementById("max-lon").value);

    //on utilise parseFloat car:
    //Les inputs HTML sont des strings alors on doit les convertir en nombres

    if (isNaN(minLat) || isNaN(maxLat) || isNaN(minLon) || isNaN(maxLon)) {
        alert("Veuillez remplir correctement la bounding box.");
        return;
        //ce test empêche les valeurs invalides
    }

    const filteredLocations = filterByBoundingBox(minLat, maxLat, minLon, maxLon);
    /*filterByBoundingBox car permet de
    filtrer les villes déjà enregistrées pour n’afficher que celles dans la zone*/

    showLoading();

    for (const loc of filteredLocations) {
        const data = await fetchWeather(loc.lat, loc.lon);
        displayWeather(loc.name, data);
        //cette boucle sert à affiche toutes les villes filtrées
    }

    clearLoading();
});
